const u=[{id:"swot-analysis",title:"Analyse SWOT d'entreprise",category:"business",description:"Analyse stratégique complète au format Texte",tags:["stratégie","analyse","swot","business"],data:{objectif:"produire une analyse SWOT complète en Texte",audience:["équipe-direction","expert"],contexte:`Entreprise fictive : "LeadGenPro"
Secteur : Logiciels B2B pour la génération de leads industriels
Public cible : investisseurs et direction commerciale`,instructions:`1. Fournis la sortie uniquement au format Texte.
2. Chaque partie SWOT (forces, faiblesses, opportunités, menaces) doit contenir 3 à 5 points clairs.
3. Utilise des phrases concises et orientées business.
4. Pas d'introduction, uniquement le Texte.`,criteres:"Réponse complète, cohérente, utilisable, format Texte strict",role:"consultant-senior",competences:"analyse stratégique, analyse SWOT",exemples:`Input: Analyser les forces internes
Output: "Large base de clients fidèles", "Technologie propriétaire innovante"

Input: Identifier une faiblesse
Output: "Dépendance à un seul canal de distribution"

Input: Opportunité de marché
Output: "Expansion vers l'Europe de l'Est"`,prefill:`{"Strengths": ["Large base de clients fidèles", "Technologie propriétaire innovante"], "Weaknesses": ["Dépendance à un seul canal de distribution"], "Opportunities": ["Expansion vers l'Europe de l'Est"], "Threats": ["Nouvelle réglementation sur la data"]}`,longueur:"moyenne",creativite:"factuelle",format:"Texte",reasoning:"justification",eagerness:"medium",reasoningEffort:"medium",verbosity:"concise",allowUnknown:!1,requireSources:!1,useXml:!0}},{id:"logistics-kpis",title:"KPIs Logistique",category:"business",description:"Définition d'indicateurs de performance logistique",tags:["kpi","logistique","performance","distribution"],data:{objectif:"définir 5 indicateurs clés de performance (KPIs) pour une chaîne logistique de distribution",audience:["expert","technique"],contexte:`Entreprise fictive : "DistribPro"
Secteur : Distribution de produits électroniques
Public cible : responsable logistique et direction opérationnelle
Objectif : Optimiser les coûts et les délais de livraison`,instructions:`1. Fournis la sortie au format Texte.
2. Définis 5 KPIs répartis dans les catégories : Approvisionnement, Transport, Stockage, Stocks.
3. Pour chaque KPI, précise : nom, définition, formule de calcul, unité, et objectif cible.
4. Inclut une brève justification du choix de chaque KPI.`,criteres:"KPIs mesurables, pertinents, réalistes, avec formules de calcul précises",role:"consultant-senior",competences:"logistique, gestion de la performance",exemples:`Input: KPI de livraison
Output: {
  "name": "Taux de livraison à temps",
  "definition": "Pourcentage de commandes livrées à la date promise",
  "formula": "(Nombre de commandes livrées à temps / Nombre total de commandes) * 100",
  "unit": "%",
  "target": "≥ 95%",
  "justification": "Indicateur clé de la satisfaction client et de l'efficacité du transport"
}`,prefill:`{"KPIs": [{"name": "Taux de livraison à temps", "definition": "Pourcentage de commandes livrées à la date promise", "formula": "(Nombre de commandes livrées à temps / Nombre total de commandes) * 100", "unit": "%", "target": "≥ 95%", "justification": "Indicateur clé de la satisfaction client et de l'efficacité du transport"}]}`,longueur:"détaillée",creativite:"factuelle",format:"Texte",reasoning:"justification",eagerness:"medium",reasoningEffort:"high",verbosity:"balanced",allowUnknown:!1,requireSources:!1,useXml:!0}},{id:"dmaic-lean-six-sigma",title:"Méthodologie DMAIC",category:"business",description:"Application de la méthodologie Lean Six Sigma DMAIC",tags:["lean","six-sigma","dmaic","qualité","amélioration"],data:{objectif:"appliquer la méthodologie DMAIC pour résoudre un problème de qualité dans une ligne de production",audience:["expert","technique"],contexte:`Entreprise fictive : "IndusPro"
Secteur : Fabrication de composants automobiles
Problème : Taux de défauts élevé sur l'assemblage des circuits imprimés
Public cible : responsable qualité et ingénieurs de production`,instructions:`1. Fournis la sortie au format Texte.
2. Structure ta réponse selon les 5 phases DMAIC (Define, Measure, Analyze, Improve, Control).
3. Pour chaque phase, décris les actions clés et les outils utilisés.
4. Inclut un exemple de résultat attendu pour la phase "Improve".`,criteres:"Structure DMAIC complète, outils appropriés, actions concrètes",role:"consultant-senior",competences:"Lean Six Sigma, amélioration des processus industriels",exemples:`Input: Phase Define
Output: {
  "Define": {
    "actions": ["Définir le problème", "Identifier les CTQs", "Cartographier le processus"],
    "tools": ["SIPOC", "Diagramme de Pareto"]
  }
}

Input: Phase Measure
Output: {
  "Measure": {
    "actions": ["Mesurer la performance actuelle", "Collecter des données"],
    "tools": ["Capabilité processus", "Gage R&R"]
  }
}`,prefill:'{"DMAIC": {"Define": {"actions": ["Définir le problème", "Identifier les CTQs", "Cartographier le processus"], "tools": ["SIPOC", "Diagramme de Pareto"]}, "Measure": {"actions": ["Mesurer la performance actuelle", "Collecter des données"], "tools": ["Capabilité processus", "Gage R&R"]}}}',longueur:"détaillée",creativite:"factuelle",format:"Texte",reasoning:"step-by-step",eagerness:"high",reasoningEffort:"high",verbosity:"detailed",allowUnknown:!1,requireSources:!0,useXml:!0}},{id:"swot-quiz",title:"Quiz SWOT",category:"education",description:"Quiz de formation sur l'analyse SWOT",tags:["quiz","formation","swot","éducation"],data:{objectif:"créer un quiz de 5 questions à choix multiples sur l'analyse SWOT",audience:["intermédiaire"],contexte:`Public cible : étudiants en gestion d'entreprise
Niveau : intermédiaire
Objectif : Évaluer la compréhension des concepts clés de l'analyse SWOT`,instructions:`1. Fournis la sortie au format Texte.
2. Chaque question doit avoir 4 options (A, B, C, D) avec une seule bonne réponse.
3. Inclut une explication pour chaque bonne réponse.
4. Les questions doivent couvrir : définition, facteurs internes/externes, interprétation de la matrice.`,criteres:"Questions pertinentes, niveau approprié, explications claires",role:"expert-marketing",competences:"stratégie d'entreprise, analyse SWOT, formation",exemples:`Input: Question sur définition SWOT
Output: {
  "question": "Que signifie le 'S' dans SWOT ?",
  "options": {
    "A": "Strategy",
    "B": "Strengths", 
    "C": "System",
    "D": "Sales"
  },
  "correct_answer": "B",
  "explanation": "Le 'S' dans SWOT signifie 'Strengths' (Forces), qui représentent les avantages internes de l'entreprise."
}`,prefill:`{"questions": [{"question": "Que signifie le 'S' dans SWOT ?", "options": {"A": "Strategy", "B": "Strengths", "C": "System", "D": "Sales"}, "correct_answer": "B", "explanation": "Le 'S' dans SWOT signifie 'Strengths' (Forces), qui représentent les avantages internes de l'entreprise."}]}`,longueur:"moyenne",creativite:"modérée",format:"Texte",reasoning:"justification",eagerness:"medium",reasoningEffort:"medium",verbosity:"balanced",allowUnknown:!1,requireSources:!1,useXml:!0}},{id:"social-media-kpis",title:"KPIs Réseaux Sociaux",category:"marketing",description:"KPIs pour campagne marketing digitale",tags:["marketing","réseaux-sociaux","kpi","digital"],data:{objectif:"recommander des KPIs pertinents pour mesurer l'efficacité d'une campagne marketing sur les réseaux sociaux",audience:["expert","technique"],contexte:`Entreprise fictive : "BrandBoost"
Secteur : Agence de communication digitale
Campagne : Lancement d'un nouveau produit cosmétique sur Instagram et TikTok
Public cible : responsable marketing et chef de projet
Objectif : Maximiser l'engagement et les conversions`,instructions:`1. Fournis la sortie au format Texte.
2. Recommande 5 KPIs avec leur définition, formule, et objectif cible.
3. Classe les KPIs par catégorie : Awareness, Engagement, Conversion.
4. Justifie le choix de chaque KPI en lien avec les objectifs de la campagne.`,criteres:"KPIs mesurables, pertinents pour réseaux sociaux, objectifs réalistes",role:"expert-marketing",competences:"marketing digital, analyse de données",exemples:`Input: KPI d'engagement
Output: {
  "name": "Taux d'engagement",
  "category": "Engagement", 
  "definition": "Pourcentage d'interactions par rapport à la portée",
  "formula": "(Likes + Commentaires + Partages) / Portée * 100",
  "target": "≥ 3%",
  "justification": "Mesure la pertinence du contenu pour l'audience cible"
}`,prefill:`{"KPIs": [{"name": "Taux d'engagement", "category": "Engagement", "definition": "Pourcentage d'interactions par rapport à la portée", "formula": "(Likes + Commentaires + Partages) / Portée * 100", "target": "≥ 3%", "justification": "Mesure la pertinence du contenu pour l'audience cible"}]}`,longueur:"détaillée",creativite:"modérée",format:"Texte",reasoning:"justification",eagerness:"medium",reasoningEffort:"medium",verbosity:"balanced",allowUnknown:!1,requireSources:!1,useXml:!0}},{id:"lean-six-sigma-deployment",title:"Déploiement Lean Six Sigma",category:"business",description:"Plan de déploiement d'une démarche Lean Six Sigma",tags:["lean","six-sigma","transformation","déploiement"],data:{objectif:"élaborer un plan de déploiement d'une démarche Lean Six Sigma dans une entreprise de services",audience:["équipe-direction","expert"],contexte:`Entreprise fictive : "ServicePro"
Secteur : Services financiers (banque en ligne)
Public cible : direction générale et responsables opérationnels
Objectif : Réduire les délais de traitement des demandes de prêt de 30%`,instructions:`1. Fournis la sortie au format Texte.
2. Structure ton plan en 3 phases : Préparation, Déploiement, Pérennisation.
3. Pour chaque phase, décris les actions clés, les acteurs impliqués, et les livrables attendus.
4. Inclut un calendrier prévisionnel sur 12 mois.`,criteres:"Plan structuré, phases logiques, calendrier réaliste, acteurs identifiés",role:"consultant-senior",competences:"Lean Six Sigma, transformation organisationnelle",exemples:`Input: Phase de préparation
Output: {
  "Préparation": {
    "actions": ["Diagnostic initial", "Formation des Yellow Belts", "Sélection des projets pilotes"],
    "actors": ["Direction", "Consultant externe", "Responsables opérationnels"],
    "deliverables": ["Rapport de diagnostic", "Plan de formation", "Cahier des charges projets pilotes"],
    "timeline": "Mois 1-3"
  }
}`,prefill:'{"plan": {"Préparation": {"actions": ["Diagnostic initial", "Formation des Yellow Belts", "Sélection des projets pilotes"], "actors": ["Direction", "Consultant externe", "Responsables opérationnels"], "deliverables": ["Rapport de diagnostic", "Plan de formation", "Cahier des charges projets pilotes"], "timeline": "Mois 1-3"}}}',longueur:"détaillée",creativite:"factuelle",format:"Texte",reasoning:"step-by-step",eagerness:"high",reasoningEffort:"high",verbosity:"detailed",allowUnknown:!1,requireSources:!0,useXml:!0}}];function y(e){return u.filter(t=>t.category===e)}function p(e){return u.find(t=>t.id===e)}function b(){return[...new Set(u.map(t=>t.category))].sort()}console.log("GRID Extension popup script loaded");const i={currentStep:"home",data:{},currentCategory:"all",searchTerm:""};function l(e){document.querySelectorAll('[id$="-view"]').forEach(t=>{t.classList.add("hidden")}),document.getElementById(e).classList.remove("hidden"),i.currentStep=e.replace("-view","")}function x(){l("home-view")}function h(){l("step1-view")}function E(){l("step1-view")}function I(){q(),l("step2-view")}function S(){C(),l("step3-view")}function q(){i.data.objectif=document.getElementById("objectif").value,i.data.audience=Array.from(document.getElementById("audience").selectedOptions).map(e=>e.value),i.data.contexte=document.getElementById("contexte").value,i.data.instructions=document.getElementById("instructions").value,i.data.criteres=document.getElementById("criteres").value}function C(){i.data.role=document.getElementById("role").value,i.data.roleCustom=document.getElementById("role-custom").value,i.data.competences=document.getElementById("competences").value,i.data.exemples=document.getElementById("exemples").value,i.data.prefill=document.getElementById("prefill").value}function B(){i.data.longueur=document.getElementById("longueur").value,i.data.creativite=document.getElementById("creativite").value,i.data.format=document.getElementById("format").value,i.data.reasoning=document.getElementById("reasoning").value,i.data.eagerness=document.getElementById("eagerness").value,i.data.reasoningEffort=document.getElementById("reasoning-effort").value,i.data.verbosity=document.getElementById("verbosity").value,i.data.allowUnknown=document.getElementById("allow-unknown").checked,i.data.requireSources=document.getElementById("require-sources").checked,i.data.useXml=document.getElementById("use-xml").checked}function T(e){document.getElementById("objectif").value=e+" ",document.getElementById("objectif").focus()}function w(e){const t=document.getElementById("competences"),n=t.value;t.value=n?n+", "+e:e}function P(){B();const e=i.data,t=e.role==="personnalisé"?e.roleCustom:v(e.role);let n;e.useXml?n=f(e,t):n=g(e,t),document.getElementById("generated-prompt").textContent=n,l("result-view")}function f(e,t){const n=[];if(n.push(`<instructions>
Tu es ${t}${e.competences?` avec les compétences suivantes : ${e.competences}`:""}.
Ta tâche est de ${e.objectif||"répondre à la demande de l'utilisateur"}.
</instructions>`),e.contexte&&n.push(`<context>
${e.contexte}
</context>`),e.instructions){const s=[e.instructions.split(`
`).map(r=>r.trim()).filter(r=>r).map((r,c)=>`${c+1}. ${r}`).join(`
`),e.criteres?`
Critères de succès : ${e.criteres}`:"",k(e.reasoning),j(e)].filter(Boolean).join("");n.push(`<requirements>${s}
</requirements>`)}e.exemples&&n.push(`<example>
${e.exemples}
</example>`);const o=[L(e),e.prefill?`Sortie attendue (à compléter) : ${e.prefill}`:""].filter(Boolean).join(`
`);return n.push(`<formatting>
${o}
</formatting>`),n.join(`

`)}function g(e,t){return`<prompt>
  <role>
    <nom>${t}</nom>
    ${e.competences?`<competences>
      ${e.competences.split(",").map(n=>`<competence>${n.trim()}</competence>`).join(`
      `)}
    </competences>`:""}
  </role>
  
  <objectif>
    ${e.objectif||"Non spécifié"}
  </objectif>
  
  <audience>
    ${e.audience.map(n=>`<type>${n}</type>`).join(`
    `)}
  </audience>
  
  ${e.contexte?`<contexte>
    ${e.contexte}
  </contexte>`:""}
  
  ${e.instructions?`<instructions>
    ${e.instructions}
  </instructions>`:""}
  
  ${e.exemples?`<exemples>
    ${e.exemples}
  </exemples>`:""}
  
  ${e.criteres?`<criteres_succes>
    ${e.criteres}
  </criteres_succes>`:""}
  
  <options>
    <longueur>${e.longueur}</longueur>
    <creativite>${e.creativite}</creativite>
    <autonomie>${e.eagerness}</autonomie>
    <profondeur_analyse>${e.reasoningEffort}</profondeur_analyse>
    <verbosity>${e.verbosity}</verbosity>
    ${e.reasoning!=="none"?`<raisonnement>${e.reasoning}</raisonnement>`:""}
    ${e.allowUnknown?"<autoriser_je_ne_sais_pas>true</autoriser_je_ne_sais_pas>":""}
    ${e.requireSources?"<exiger_sources>true</exiger_sources>":""}
  </options>
  
  <format_de_sortie>
    <type>${e.format}</type>
    ${e.prefill?`<prefill>${e.prefill}</prefill>`:""}
  </format_de_sortie>
</prompt>`}function k(e){const t={"step-by-step":"Réfléchis étape par étape avant de donner ta réponse finale.",justification:"Justifie chacun de tes choix et explique ton raisonnement.","auto-reflexion":"Commence par analyser la demande, réfléchis aux approches possibles, puis donne ta réponse."};return e!=="none"&&t[e]?`
${t[e]}`:""}function j(e){const t=[],n={json:"Fournis la sortie uniquement au format JSON.",rapport:"Structure ta réponse comme un rapport professionnel.",liste:"Présente ta réponse sous forme de liste organisée."};n[e.format]&&t.push(n[e.format]);const o={courte:"Réponse concise (100-300 mots maximum).",détaillée:"Réponse détaillée et exhaustive (600+ mots)."};return o[e.longueur]&&t.push(o[e.longueur]),e.requireSources&&t.push("Inclus des sources ou références quand c'est pertinent."),e.allowUnknown&&t.push(`N'hésite pas à dire "Je ne sais pas" si tu n'es pas certain.`),t.length>0?`
${t.join(`
`)}`:""}function L(e){let t=`Format de sortie requis : ${e.format}`;return e.format==="json"&&(t+=`
Pas d'introduction, uniquement le JSON.`),t}function v(e){return{"consultant-senior":"Consultant Senior en Stratégie","analyste-données":"Analyste de Données Expert","expert-marketing":"Expert Marketing Digital","développeur-senior":"Développeur Senior","rédacteur-technique":"Rédacteur Technique Spécialisé"}[e]||"Expert dans le domaine"}function $(){const e=document.getElementById("generated-prompt").textContent;navigator.clipboard.writeText(e).then(()=>{const t=document.getElementById("copy-btn"),n=t.textContent;t.textContent="Copié !",t.style.background="#10b981",setTimeout(()=>{t.textContent=n,t.style.background=""},2e3)})}function D(){l("library-view"),m()}function m(){var e=document.getElementById("library-content");if(e){var t=b(),n=O(),o='<div class="library-header"><div class="library-search"><input type="text" id="library-search" class="form-input" placeholder="Rechercher des exemples..." value="'+i.searchTerm+'"></div><div class="library-filters"><select id="category-filter" class="form-input"><option value="all">Toutes les catégories</option>'+t.map(function(r){return'<option value="'+r+'"'+(i.currentCategory===r?" selected":"")+">"+A(r)+"</option>"}).join("")+'</select></div></div><div class="library-examples">'+n.map(function(r){return'<div class="example-card" data-example-id="'+r.id+'"><h3>'+r.title+'</h3><p class="example-description">'+r.description+'</p><div class="example-tags">'+r.tags.map(function(c){return'<span class="tag">'+c+"</span>"}).join("")+'</div><div class="example-actions"><button class="btn-secondary" data-action="preview-example" data-example-id="'+r.id+'">Aperçu</button><button class="btn-primary" data-action="use-example" data-example-id="'+r.id+'">Utiliser</button></div></div>'}).join("")+"</div>";e.innerHTML=o;var a=document.getElementById("library-search"),s=document.getElementById("category-filter");a&&a.addEventListener("input",function(r){i.searchTerm=r.target.value,m()}),s&&s.addEventListener("change",function(r){i.currentCategory=r.target.value,m()}),document.querySelectorAll('[data-action="preview-example"]').forEach(function(r){r.addEventListener("click",function(c){var d=c.target.getAttribute("data-example-id");M(d)})}),document.querySelectorAll('[data-action="use-example"]').forEach(function(r){r.addEventListener("click",function(c){var d=c.target.getAttribute("data-example-id");_(d)})})}}function O(){var e=u;if(i.currentCategory!=="all"&&(e=y(i.currentCategory)),i.searchTerm.trim()){var t=i.searchTerm.toLowerCase().split(" ");e=e.filter(function(n){return t.some(function(o){return n.title.toLowerCase().includes(o)||n.description.toLowerCase().includes(o)||n.tags.some(function(a){return a.toLowerCase().includes(o)})})})}return e}function A(e){return{business:"Business",marketing:"Marketing",education:"Éducation",technical:"Technique",creative:"Créatif"}[e]||e}function M(e){var t=p(e);if(t){var n=t.data,o=n.role==="personnalisé"?n.roleCustom:v(n.role),a=n.useXml?f(n,o):g(n,o);R(t.title,a)}}function R(e,t){var n=document.createElement("div");n.className="modal-overlay",n.innerHTML='<div class="modal-content"><div class="modal-header"><h2>'+e+'</h2><button class="modal-close" data-action="close-modal">&times;</button></div><div class="modal-body"><pre class="prompt-preview">'+t+'</pre></div><div class="modal-footer"><button class="btn-secondary" data-action="close-modal">Fermer</button><button class="btn-primary" data-action="copy-preview">Copier</button></div></div>',document.body.appendChild(n),n.addEventListener("click",function(o){(o.target.classList.contains("modal-overlay")||o.target.getAttribute("data-action")==="close-modal")&&document.body.removeChild(n)}),n.querySelector('[data-action="copy-preview"]').addEventListener("click",function(){navigator.clipboard.writeText(t).then(function(){var o=n.querySelector('[data-action="copy-preview"]'),a=o.textContent;o.textContent="Copié !",setTimeout(function(){o.textContent=a},2e3)})})}function _(e){var t=p(e);t&&(i.data=Object.assign({},t.data),F(t.data),l("step1-view"))}function F(e){setTimeout(function(){if(e.objectif&&(document.getElementById("objectif").value=e.objectif),e.contexte&&(document.getElementById("contexte").value=e.contexte),e.instructions&&(document.getElementById("instructions").value=e.instructions),e.criteres&&(document.getElementById("criteres").value=e.criteres),e.audience){var t=document.getElementById("audience");t&&Array.from(t.options).forEach(function(o){o.selected=e.audience.indexOf(o.value)!==-1})}if(e.role){var n=document.getElementById("role");n&&(n.value=e.role,e.role==="personnalisé"&&e.roleCustom&&(document.getElementById("role-custom").classList.remove("hidden"),document.getElementById("role-custom").value=e.roleCustom))}e.competences&&(document.getElementById("competences").value=e.competences),e.exemples&&(document.getElementById("exemples").value=e.exemples),e.prefill&&(document.getElementById("prefill").value=e.prefill),e.longueur&&(document.getElementById("longueur").value=e.longueur),e.creativite&&(document.getElementById("creativite").value=e.creativite),e.format&&(document.getElementById("format").value=e.format),e.reasoning&&(document.getElementById("reasoning").value=e.reasoning),e.eagerness&&(document.getElementById("eagerness").value=e.eagerness),e.reasoningEffort&&(document.getElementById("reasoning-effort").value=e.reasoningEffort),e.verbosity&&(document.getElementById("verbosity").value=e.verbosity),typeof e.allowUnknown<"u"&&(document.getElementById("allow-unknown").checked=e.allowUnknown),typeof e.requireSources<"u"&&(document.getElementById("require-sources").checked=e.requireSources),typeof e.useXml<"u"&&(document.getElementById("use-xml").checked=e.useXml)},100)}document.addEventListener("DOMContentLoaded",function(){console.log("DOM loaded, initializing GRID extension...");const e=document.querySelector('[data-action="start-builder"]'),t=document.querySelector('[data-action="show-library"]');e&&e.addEventListener("click",h),t&&t.addEventListener("click",D),document.querySelectorAll('[data-action="go-home"]').forEach(s=>{s.addEventListener("click",x)}),document.querySelectorAll('[data-action="go-step1"]').forEach(s=>{s.addEventListener("click",E)}),document.querySelectorAll('[data-action="go-step2"]').forEach(s=>{s.addEventListener("click",I)}),document.querySelectorAll('[data-action="go-step3"]').forEach(s=>{s.addEventListener("click",S)}),document.querySelectorAll('[data-action="generate-prompt"]').forEach(s=>{s.addEventListener("click",P)}),document.querySelectorAll('[data-action="copy-prompt"]').forEach(s=>{s.addEventListener("click",$)}),document.querySelectorAll('[data-suggestion="objectif"]').forEach(s=>{s.addEventListener("click",function(){T(this.textContent)})}),document.querySelectorAll('[data-suggestion="competence"]').forEach(s=>{s.addEventListener("click",function(){w(this.textContent)})});const n=document.getElementById("role"),o=document.getElementById("role-custom");n&&o&&n.addEventListener("change",function(){this.value==="personnalisé"?(o.classList.remove("hidden"),o.focus()):o.classList.add("hidden")});function a(){const s=document.getElementById("template-count-badge");if(s&&u){const r=u.length;s.textContent=`${r} TEMPLATE${r>1?"S":""}`}}a(),console.log("GRID extension initialized successfully")});
