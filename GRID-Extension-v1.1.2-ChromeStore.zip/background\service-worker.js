chrome.runtime.onInstalled.addListener(()=>{console.log("GRID Extension installed")});
