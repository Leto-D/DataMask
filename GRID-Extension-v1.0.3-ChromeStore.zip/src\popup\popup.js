console.log("🚀 GRID Extension popup script loaded");const k={fr:{app_title:"GRID - AI Prompt Builder",app_subtitle:"Création de Prompts & IA",app_description:"Outil de productivité pour créer des prompts efficaces",start_button:"Commencer",library_button:"Bibliothèque",library:"Bibliothèque",library_subtitle:"Templates et exemples de prompts",step1:"Étape 1: Définir l'objectif",step2:"Étape 2: Structurer",step3:"Étape 3: Personnaliser",library_title:"Bibliothèque",result_title:"Prompt généré",objective_label:"Objectif principal",objective_placeholder:"Décrivez précisément ce que vous attendez de l'IA...",audience_label:"Audience cible",audience_help:"Maintenez Ctrl/Cmd pour sélectionner plusieurs options",context_label:"Contexte",context_placeholder:"Ex: Entreprise: LeadGenPro, Secteur: Logiciels B2B, Public: investisseurs...",instructions_label:"Instructions séquentielles (optionnel)",instructions_placeholder:`1. Effectuer une analyse...
2. Proposer des stratégies...
3. Identifier les KPIs...`,success_criteria_label:"Critères de succès",success_criteria_placeholder:"Ex: Réponse complète, cohérente, utilisable, avec 3-5 points par section...",role_label:"Rôle et personnalité",role_placeholder:"Choisir un rôle...",role_custom_placeholder:"Décrivez le rôle personnalisé...",skills_label:"Compétences clés",skills_placeholder:"Ex: Analyse stratégique, Optimisation, Leadership...",examples_label:"Exemples Input/Output (multishot)",examples_placeholder:`Exemple 1:
Input: [votre exemple]
Output: [réponse attendue]

Exemple 2:
...`,prefill_label:"Préremplissage de la réponse (optionnel)",prefill_placeholder:'Ex: {"Strengths": [, "Weaknesses": [',response_length_label:"Longueur de réponse",creativity_level_label:"Niveau de créativité",output_format_label:"Format de sortie",reasoning_label:"Raisonnement (Chain-of-thought)",advanced_ai_label:"Paramètres IA avancés",autonomy_label:"Autonomie (Eagerness)",analysis_depth_label:"Profondeur d'analyse",verbosity_label:"Verbosité",advanced_options_label:"Options avancées","suggestions.write_report":"Rédiger un rapport","suggestions.analyze_data":"Analyser des données","suggestions.create_strategy":"Créer une stratégie","suggestions.solve_problem":"Résoudre un problème","suggestions.optimize_process":"Optimiser un processus","suggestions.evaluate_options":"Évaluer des options","suggestions.plan_project":"Planifier un projet","suggestions.present_results":"Présenter des résultats","suggestions.strategic_analysis":"Analyse stratégique","suggestions.critical_thinking":"Pensée critique","suggestions.communication":"Communication","suggestions.creativity":"Créativité","suggestions.leadership":"Leadership","suggestions.innovation":"Innovation","suggestions.problem_solving":"Résolution de problèmes","suggestions.project_management":"Gestion de projet","suggestions.data_analysis":"Analyse de données","suggestions.business_vision":"Vision business","roles.senior_consultant":"Consultant Senior en Stratégie","roles.data_analyst":"Analyste de Données","roles.marketing_expert":"Expert Marketing","roles.senior_developer":"Développeur Senior","roles.technical_writer":"Rédacteur Technique","roles.custom":"Rôle personnalisé...","roles.expert":"Expert dans le domaine",not_specified:"Non spécifié",copy_button:"Copier",back_button:"Retour",next_button:"Suivant",generate_button:"Générer",footer:"© 2025 GRID - AI Prompt Builder (By LetoD)","features.fast":"Rapide","features.structured":"Structuré","features.efficient":"Efficace","audiences.beginner":"Débutant","audiences.intermediate":"Intermédiaire","audiences.expert":"Expert","audiences.management":"Équipe de direction","audiences.general_public":"Grand public","audiences.technical":"Public technique",examples_help:"Fournissez 2-5 exemples avec format Input → Output",prefill_help:"Format de sortie que l'IA doit commencer à remplir",require_sources:"Exiger des sources",use_xml:"Utiliser structure XML avancée","lengths.short":"Courte (100-300 mots)","lengths.medium":"Moyenne (300-600 mots)","lengths.detailed":"Détaillée (600+ mots)","formats.text":"Texte libre","formats.report":"Rapport structuré","formats.list":"Liste à puces","formats.json":"Format JSON","formats.table":"Tableau","creativity.factual":"Factuelle (0% créativité)","creativity.moderate":"Modérée (30% créativité)","creativity.creative":"Créative (70% créativité)","reasoning_types.none":"Aucun raisonnement spécifique","reasoning_types.step_by_step":"Raisonnement étape par étape","reasoning_types.justification":"Justifier les choix","autonomy_levels.low":"Basse - L'IA pose des questions","autonomy_levels.medium":"Moyenne - Équilibrée","autonomy_levels.high":"Haute - L'IA est proactive","analysis_depths.low":"Analyse superficielle","analysis_depths.medium":"Analyse standard","analysis_depths.high":"Analyse approfondie","verbosity_levels.concise":"Concise","verbosity_levels.balanced":"Équilibrée","verbosity_levels.detailed":"Détaillée"},en:{app_title:"GRID - AI Prompt Builder",app_subtitle:"Prompt Creation & AI",app_description:"Productivity tool for creating effective prompts",start_button:"Start",library_button:"Library",library:"Library",library_subtitle:"Templates and prompt examples",step1:"Step 1: Define objective",step2:"Step 2: Structure",step3:"Step 3: Personalize",library_title:"Library",result_title:"Generated prompt",objective_label:"Main objective",objective_placeholder:"Describe precisely what you expect from the AI...",audience_label:"Target audience",audience_help:"Hold Ctrl/Cmd to select multiple options",context_label:"Context",context_placeholder:"Ex: Company: LeadGenPro, Sector: B2B Software, Audience: investors...",instructions_label:"Sequential instructions (optional)",instructions_placeholder:`1. Perform an analysis...
2. Propose strategies...
3. Identify KPIs...`,success_criteria_label:"Success criteria",success_criteria_placeholder:"Ex: Complete, coherent, usable response, with 3-5 points per section...",role_label:"Role and personality",role_placeholder:"Choose a role...",role_custom_placeholder:"Describe the custom role...",skills_label:"Key skills",skills_placeholder:"Ex: Strategic analysis, Optimization, Leadership...",examples_label:"Input/Output examples (multishot)",examples_placeholder:`Example 1:
Input: [your example]
Output: [expected response]

Example 2:
...`,prefill_label:"Response prefill (optional)",prefill_placeholder:'Ex: {"Strengths": [, "Weaknesses": [',response_length_label:"Response length",creativity_level_label:"Creativity level",output_format_label:"Output format",reasoning_label:"Reasoning (Chain-of-thought)",advanced_ai_label:"Advanced AI parameters",autonomy_label:"Autonomy (Eagerness)",analysis_depth_label:"Analysis depth",verbosity_label:"Verbosity",advanced_options_label:"Advanced options","suggestions.write_report":"Write a report","suggestions.analyze_data":"Analyze data","suggestions.create_strategy":"Create a strategy","suggestions.solve_problem":"Solve a problem","suggestions.optimize_process":"Optimize a process","suggestions.evaluate_options":"Evaluate options","suggestions.plan_project":"Plan a project","suggestions.present_results":"Present results","suggestions.strategic_analysis":"Strategic analysis","suggestions.critical_thinking":"Critical thinking","suggestions.communication":"Communication","suggestions.creativity":"Creativity","suggestions.leadership":"Leadership","suggestions.innovation":"Innovation","suggestions.problem_solving":"Problem solving","suggestions.project_management":"Project management","suggestions.data_analysis":"Data analysis","suggestions.business_vision":"Business vision","roles.senior_consultant":"Senior Strategy Consultant","roles.data_analyst":"Data Analyst","roles.marketing_expert":"Marketing Expert","roles.senior_developer":"Senior Developer","roles.technical_writer":"Technical Writer","roles.custom":"Custom role...","roles.expert":"Domain Expert",not_specified:"Not specified",copy_button:"Copy",back_button:"Back",next_button:"Next",generate_button:"Generate",footer:"© 2025 GRID - AI Prompt Builder (By LetoD)","features.fast":"Fast","features.structured":"Structured","features.efficient":"Efficient","audiences.beginner":"Beginner","audiences.intermediate":"Intermediate","audiences.expert":"Expert","audiences.management":"Management team","audiences.general_public":"General public","audiences.technical":"Technical audience",examples_help:"Provide 2-5 examples with Input → Output format",prefill_help:"Output format that AI should start filling",require_sources:"Require sources",use_xml:"Use advanced XML structure","lengths.short":"Short (100-300 words)","lengths.medium":"Medium (300-600 words)","lengths.detailed":"Detailed (600+ words)","formats.text":"Free text","formats.report":"Structured report","formats.list":"Bullet list","formats.json":"JSON format","formats.table":"Table","creativity.factual":"Factual (0% creativity)","creativity.moderate":"Moderate (30% creativity)","creativity.creative":"Creative (70% creativity)","reasoning_types.none":"No specific reasoning","reasoning_types.step_by_step":"Step-by-step reasoning","reasoning_types.justification":"Justify choices","autonomy_levels.low":"Low - AI asks questions","autonomy_levels.medium":"Medium - Balanced","autonomy_levels.high":"High - AI is proactive","analysis_depths.low":"Superficial analysis","analysis_depths.medium":"Standard analysis","analysis_depths.high":"Deep analysis","verbosity_levels.concise":"Concise","verbosity_levels.balanced":"Balanced","verbosity_levels.detailed":"Detailed"},de:{app_title:"GRID - AI Prompt Builder",app_subtitle:"Prompt-Erstellung & KI",app_description:"Produktivitätstool für die Erstellung effektiver Prompts",start_button:"Starten",library_button:"Bibliothek",library:"Bibliothek",library_subtitle:"Vorlagen und Prompt-Beispiele",step1:"Schritt 1: Ziel definieren",step2:"Schritt 2: Strukturieren",step3:"Schritt 3: Personalisieren",library_title:"Bibliothek",result_title:"Generierter Prompt",objective_label:"Hauptziel",objective_placeholder:"Beschreiben Sie genau, was Sie von der KI erwarten...",audience_label:"Zielgruppe",audience_help:"Halten Sie Strg/Cmd gedrückt, um mehrere Optionen auszuwählen",context_label:"Kontext",context_placeholder:"Bsp: Unternehmen: LeadGenPro, Sektor: B2B Software, Publikum: Investoren...",instructions_label:"Sequentielle Anweisungen (optional)",instructions_placeholder:`1. Eine Analyse durchführen...
2. Strategien vorschlagen...
3. KPIs identifizieren...`,success_criteria_label:"Erfolgskriterien",success_criteria_placeholder:"Bsp: Vollständige, kohärente, nutzbare Antwort mit 3-5 Punkten pro Abschnitt...",role_label:"Rolle und Persönlichkeit",role_placeholder:"Rolle wählen...",role_custom_placeholder:"Beschreiben Sie die benutzerdefinierte Rolle...",skills_label:"Kernkompetenzen",skills_placeholder:"Bsp: Strategische Analyse, Optimierung, Führung...",examples_label:"Input/Output-Beispiele (multishot)",examples_placeholder:`Beispiel 1:
Input: [Ihr Beispiel]
Output: [erwartete Antwort]

Beispiel 2:
...`,prefill_label:"Antwort-Vorlage (optional)",prefill_placeholder:'Bsp: {"Strengths": [, "Weaknesses": [',response_length_label:"Antwortlänge",creativity_level_label:"Kreativitätsniveau",output_format_label:"Ausgabeformat",reasoning_label:"Argumentation (Chain-of-thought)",advanced_ai_label:"Erweiterte KI-Parameter",autonomy_label:"Autonomie (Eagerness)",analysis_depth_label:"Analysetiefe",verbosity_label:"Ausführlichkeit",advanced_options_label:"Erweiterte Optionen","suggestions.write_report":"Einen Bericht schreiben","suggestions.analyze_data":"Daten analysieren","suggestions.create_strategy":"Eine Strategie erstellen","suggestions.solve_problem":"Ein Problem lösen","suggestions.optimize_process":"Einen Prozess optimieren","suggestions.evaluate_options":"Optionen bewerten","suggestions.plan_project":"Ein Projekt planen","suggestions.present_results":"Ergebnisse präsentieren","suggestions.strategic_analysis":"Strategische Analyse","suggestions.critical_thinking":"Kritisches Denken","suggestions.communication":"Kommunikation","suggestions.creativity":"Kreativität","suggestions.leadership":"Führung","suggestions.innovation":"Innovation","suggestions.problem_solving":"Problemlösung","suggestions.project_management":"Projektmanagement","suggestions.data_analysis":"Datenanalyse","suggestions.business_vision":"Geschäftsvision","roles.senior_consultant":"Senior Strategieberater","roles.data_analyst":"Datenanalyst","roles.marketing_expert":"Marketing-Experte","roles.senior_developer":"Senior Entwickler","roles.technical_writer":"Technischer Redakteur","roles.custom":"Benutzerdefinierte Rolle...","roles.expert":"Experte im Bereich",not_specified:"Nicht spezifiziert",copy_button:"Kopieren",back_button:"Zurück",next_button:"Weiter",generate_button:"Generieren",footer:"© 2025 GRID - AI Prompt Builder (By LetoD)","features.fast":"Schnell","features.structured":"Strukturiert","features.efficient":"Effizient","audiences.beginner":"Anfänger","audiences.intermediate":"Fortgeschritten","audiences.expert":"Experte","audiences.management":"Führungsteam","audiences.general_public":"Allgemeine Öffentlichkeit","audiences.technical":"Technisches Publikum",examples_help:"Geben Sie 2-5 Beispiele im Input → Output Format an",prefill_help:"Ausgabeformat, das die KI zu füllen beginnen soll",require_sources:"Quellen erforderlich",use_xml:"Erweiterte XML-Struktur verwenden","lengths.short":"Kurz (100-300 Wörter)","lengths.medium":"Mittel (300-600 Wörter)","lengths.detailed":"Detailliert (600+ Wörter)","formats.text":"Freier Text","formats.report":"Strukturierter Bericht","formats.list":"Aufzählung","formats.json":"JSON-Format","formats.table":"Tabelle","creativity.factual":"Sachlich (0% Kreativität)","creativity.moderate":"Moderat (30% Kreativität)","creativity.creative":"Kreativ (70% Kreativität)","reasoning_types.none":"Keine spezifische Argumentation","reasoning_types.step_by_step":"Schritt-für-Schritt Argumentation","reasoning_types.justification":"Entscheidungen begründen","autonomy_levels.low":"Niedrig - KI stellt Fragen","autonomy_levels.medium":"Mittel - Ausgewogen","autonomy_levels.high":"Hoch - KI ist proaktiv","analysis_depths.low":"Oberflächliche Analyse","analysis_depths.medium":"Standard-Analyse","analysis_depths.high":"Tiefgehende Analyse","verbosity_levels.concise":"Prägnant","verbosity_levels.balanced":"Ausgewogen","verbosity_levels.detailed":"Ausführlich"}};class ${constructor(){this.currentLanguage=this.loadLanguage()}loadLanguage(){return localStorage.getItem("grid-language")||"fr"}setLanguage(e){this.currentLanguage=e,localStorage.setItem("grid-language",e),this.updateDOM()}t(e,o=null){return k[this.currentLanguage]?.[e]||o||e}updateDOM(){document.querySelectorAll("[data-i18n]").forEach(e=>{const o=e.getAttribute("data-i18n");if(o){if(e.closest("button")&&e.closest("button").querySelector("svg"))return;e.textContent=this.t(o)}}),document.querySelectorAll("[data-i18n-placeholder]").forEach(e=>{const o=e.getAttribute("data-i18n-placeholder");o&&(e.placeholder=this.t(o))}),document.querySelectorAll("[data-i18n-option]").forEach(e=>{const o=e.getAttribute("data-i18n-option");o&&(e.textContent=this.t(o))}),this.updateSuggestions()}updateSuggestions(){document.querySelectorAll('.suggestion-tag[data-suggestion="objectif"]').forEach((e,o)=>{const i=["suggestions.write_report","suggestions.analyze_data","suggestions.create_strategy","suggestions.solve_problem","suggestions.optimize_process","suggestions.evaluate_options","suggestions.plan_project","suggestions.present_results"];i[o]&&(e.textContent=this.t(i[o]))}),document.querySelectorAll('.suggestion-tag[data-suggestion="competence"]').forEach((e,o)=>{const i=["suggestions.strategic_analysis","suggestions.critical_thinking","suggestions.communication","suggestions.creativity","suggestions.leadership","suggestions.innovation","suggestions.problem_solving","suggestions.project_management","suggestions.data_analysis","suggestions.business_vision"];i[o]&&(e.textContent=this.t(i[o]))})}}const s=new $,f={strategy:[{id:"business-strategy",title_fr:"Stratégie Business",title_en:"Business Strategy",title_de:"Geschäftsstrategie",description_fr:"Analyser et développer des stratégies business",description_en:"Analyze and develop business strategies",description_de:"Geschäftsstrategien analysieren und entwickeln",prompt:`<prompt>
  <role>
    <nom>Consultant Senior en Stratégie</nom>
    <competences>Analyse stratégique, Vision business, Planification</competences>
  </role>
  
  <objectif>
    Développer une stratégie business complète pour [ENTREPRISE] dans le secteur [SECTEUR]
  </objectif>
  
  <audience>
    <type>expert</type>
    <type>équipe-direction</type>
  </audience>
  
  <contexte>
    Entreprise: [ENTREPRISE]
    Secteur: [SECTEUR]
    Taille: [TAILLE]
    Objectifs: [OBJECTIFS]
  </contexte>
  
  <options>
    <longueur>détaillée</longueur>
    <creativite>modérée</creativite>
    <autonomie>medium</autonomie>
    <profondeur_analyse>high</profondeur_analyse>
    <verbosity>balanced</verbosity>
  </options>
  
  <format_de_sortie>
    <type>rapport</type>
  </format_de_sortie>
</prompt>`},{id:"market-analysis",title_fr:"Analyse de Marché",title_en:"Market Analysis",title_de:"Marktanalyse",description_fr:"Analyser un marché et ses opportunités",description_en:"Analyze a market and its opportunities",description_de:"Markt und Chancen analysieren",prompt:`<prompt>
  <role>
    <nom>Analyste de Marché</nom>
    <competences>Recherche, Analyse de données, Veille concurrentielle</competences>
  </role>
  
  <objectif>
    Effectuer une analyse complète du marché [MARCHE] pour identifier les opportunités et menaces
  </objectif>
  
  <audience>
    <type>expert</type>
    <type>équipe-direction</type>
  </audience>
  
  <options>
    <longueur>détaillée</longueur>
    <creativite>factuelle</creativite>
    <autonomie>medium</autonomie>
    <profondeur_analyse>high</profondeur_analyse>
    <verbosity>detailed</verbosity>
  </options>
  
  <format_de_sortie>
    <type>rapport</type>
  </format_de_sortie>
</prompt>`}],content:[{id:"technical-writing",title_fr:"Rédaction Technique",title_en:"Technical Writing",title_de:"Technisches Schreiben",description_fr:"Créer de la documentation technique claire",description_en:"Create clear technical documentation",description_de:"Klare technische Dokumentation erstellen",prompt:`<prompt>
  <role>
    <nom>Rédacteur Technique</nom>
    <competences>Documentation, Communication technique, Vulgarisation</competences>
  </role>
  
  <objectif>
    Rédiger une documentation technique pour [PRODUIT/SERVICE] destinée à [AUDIENCE_CIBLE]
  </objectif>
  
  <audience>
    <type>technique</type>
    <type>débutant</type>
  </audience>
  
  <options>
    <longueur>détaillée</longueur>
    <creativite>factuelle</creativite>
    <autonomie>medium</autonomie>
    <profondeur_analyse>medium</profondeur_analyse>
    <verbosity>balanced</verbosity>
  </options>
  
  <format_de_sortie>
    <type>rapport</type>
  </format_de_sortie>
</prompt>`},{id:"marketing-copy",title_fr:"Copy Marketing",title_en:"Marketing Copy",title_de:"Marketing-Text",description_fr:"Créer du contenu marketing persuasif",description_en:"Create persuasive marketing content",description_de:"Überzeugenden Marketing-Content erstellen",prompt:`<prompt>
  <role>
    <nom>Expert Marketing</nom>
    <competences>Copywriting, Persuasion, Communication</competences>
  </role>
  
  <objectif>
    Créer un copy marketing pour [PRODUIT] ciblant [AUDIENCE] avec l'objectif de [OBJECTIF_MARKETING]
  </objectif>
  
  <audience>
    <type>grand-public</type>
  </audience>
  
  <options>
    <longueur>moyenne</longueur>
    <creativite>créative</creativite>
    <autonomie>high</autonomie>
    <profondeur_analyse>medium</profondeur_analyse>
    <verbosity>concise</verbosity>
  </options>
  
  <format_de_sortie>
    <type>texte</type>
  </format_de_sortie>
</prompt>`}],analysis:[{id:"data-analysis",title_fr:"Analyse de Données",title_en:"Data Analysis",title_de:"Datenanalyse",description_fr:"Analyser et interpréter des données",description_en:"Analyze and interpret data",description_de:"Daten analysieren und interpretieren",prompt:`<prompt>
  <role>
    <nom>Analyste de Données</nom>
    <competences>Statistiques, Visualisation, Insights business</competences>
  </role>
  
  <objectif>
    Analyser les données [TYPE_DONNEES] pour identifier les tendances et recommandations
  </objectif>
  
  <audience>
    <type>expert</type>
    <type>équipe-direction</type>
  </audience>
  
  <options>
    <longueur>détaillée</longueur>
    <creativite>factuelle</creativite>
    <autonomie>medium</autonomie>
    <profondeur_analyse>high</profondeur_analyse>
    <verbosity>detailed</verbosity>
  </options>
  
  <format_de_sortie>
    <type>rapport</type>
  </format_de_sortie>
</prompt>`}]};function B(t){return f[t]||[]}function h(t){for(const e in f){const o=f[e].find(i=>i.id===t);if(o)return o}return null}const n={currentStep:"home",data:{}};function l(t){console.log("📍 showView appelée avec:",t);try{document.querySelectorAll('[id$="-view"]').forEach(o=>{o.classList.add("hidden"),console.log("  - Masqué:",o.id)});const e=document.getElementById(t);e?(e.classList.remove("hidden"),n.currentStep=t.replace("-view",""),console.log("  ✅ Vue affichée:",t)):console.error("  ❌ Vue non trouvée:",t)}catch(e){console.error("❌ Erreur dans showView:",e)}}function v(){console.log("🏠 goHome appelée"),l("home-view")}function _(){console.log("🚀 startBuilder appelée"),l("step1-view")}function x(){console.log("1️⃣ goToStep1 appelée"),l("step1-view")}function E(){console.log("2️⃣ goToStep2 appelée"),j(),l("step2-view")}function S(){console.log("3️⃣ goToStep3 appelée"),P(),l("step3-view")}function A(){console.log("📚 showLibrary appelée"),R(),l("library-view")}function I(){console.log("✨ generatePrompt appelée"),q();const t=D(),e=document.getElementById("generated-prompt");e&&(e.textContent=t),l("result-view")}function w(){console.log("📋 copyPrompt appelée");const t=document.getElementById("generated-prompt");if(t&&t.textContent)try{navigator.clipboard.writeText(t.textContent).then(()=>{console.log("✅ Prompt copié avec succès");const e=document.querySelector('[data-action="copy-prompt"]');if(e){const o=e.style.background;e.style.background="var(--color-success)",setTimeout(()=>{e.style.background=o},1e3)}}).catch(e=>{console.error("❌ Erreur lors de la copie:",e),g(t.textContent)})}catch(e){console.error("❌ Clipboard API non supportée:",e),g(t.textContent)}else console.warn("⚠️ Aucun prompt à copier")}function g(t){const e=document.createElement("textarea");e.value=t,document.body.appendChild(e),e.focus(),e.select();try{document.execCommand("copy"),console.log("✅ Prompt copié avec la méthode fallback")}catch(o){console.error("❌ Erreur avec la méthode fallback:",o)}document.body.removeChild(e)}function j(){console.log("📊 Collecte des données étape 1");const t=document.getElementById("objective"),e=document.getElementById("audience");if(t&&(n.data.objective=t.value,console.log("  - Objectif:",n.data.objective)),e){const o=Array.from(e.selectedOptions).map(i=>i.value);n.data.audience=o,console.log("  - Audience:",n.data.audience)}}function P(){console.log("📊 Collecte des données étape 2");const t=document.getElementById("context"),e=document.getElementById("instructions"),o=document.getElementById("criteres");t&&(n.data.context=t.value,console.log("  - Contexte:",n.data.context)),e&&(n.data.instructions=e.value,console.log("  - Instructions:",n.data.instructions)),o&&(n.data.criteres=o.value,console.log("  - Critères:",n.data.criteres))}function q(){console.log("📊 Collecte des données étape 3");const t=document.getElementById("role"),e=document.getElementById("role-custom"),o=document.getElementById("competences"),i=document.getElementById("exemples"),r=document.getElementById("prefill"),c=document.getElementById("longueur"),a=document.getElementById("creativite"),p=document.getElementById("format"),d=document.getElementById("reasoning"),m=document.getElementById("autonomie"),y=document.getElementById("profondeur_analyse"),b=document.getElementById("verbosity");t&&(n.data.role=t.value,console.log("  - Rôle:",n.data.role)),e&&e.value&&(n.data.roleCustom=e.value,console.log("  - Rôle personnalisé:",n.data.roleCustom)),o&&(n.data.competences=o.value,console.log("  - Compétences:",n.data.competences)),i&&(n.data.exemples=i.value,console.log("  - Exemples:",n.data.exemples)),r&&(n.data.prefill=r.value,console.log("  - Prefill:",n.data.prefill)),c&&(n.data.longueur=c.value,console.log("  - Longueur:",n.data.longueur)),a&&(n.data.creativite=a.value,console.log("  - Créativité:",n.data.creativite)),p&&(n.data.format=p.value,console.log("  - Format:",n.data.format)),d&&(n.data.reasoning=d.value,console.log("  - Reasoning:",n.data.reasoning)),m&&(n.data.autonomie=m.value,console.log("  - Autonomie:",n.data.autonomie)),y&&(n.data.profondeur=y.value,console.log("  - Profondeur:",n.data.profondeur)),b&&(n.data.verbosity=b.value,console.log("  - Verbosity:",n.data.verbosity))}function u(t,e){const i={longueur:{courte:{fr:"courte",en:"short",de:"kurz"},moyenne:{fr:"moyenne",en:"medium",de:"mittel"},détaillée:{fr:"détaillée",en:"detailed",de:"detailliert"}},creativite:{factuelle:{fr:"factuelle",en:"factual",de:"sachlich"},modérée:{fr:"modérée",en:"moderate",de:"moderat"},créative:{fr:"créative",en:"creative",de:"kreativ"}},format:{texte:{fr:"texte",en:"text",de:"text"},rapport:{fr:"rapport",en:"report",de:"bericht"},liste:{fr:"liste",en:"list",de:"liste"},json:{fr:"json",en:"json",de:"json"},tableau:{fr:"tableau",en:"table",de:"tabelle"}},reasoning:{none:{fr:"aucun",en:"none",de:"keine"},"step-by-step":{fr:"étape par étape",en:"step-by-step",de:"schritt für schritt"},justification:{fr:"justification",en:"justification",de:"begründung"}},autonomie:{low:{fr:"faible",en:"low",de:"niedrig"},medium:{fr:"moyenne",en:"medium",de:"mittel"},high:{fr:"élevée",en:"high",de:"hoch"}},profondeur:{low:{fr:"superficielle",en:"superficial",de:"oberflächlich"},medium:{fr:"standard",en:"standard",de:"standard"},high:{fr:"approfondie",en:"deep",de:"tiefgehend"}},verbosity:{concise:{fr:"concise",en:"concise",de:"prägnant"},balanced:{fr:"équilibrée",en:"balanced",de:"ausgewogen"},detailed:{fr:"détaillée",en:"detailed",de:"ausführlich"}}}[t];return i&&i[e]&&i[e][s.currentLanguage]||e}function L(){const t={fr:{role:"role",nom:"nom",competences:"competences",objectif:"objectif",audience:"audience",type:"type",contexte:"contexte",instructions_sequentielles:"instructions_sequentielles",criteres_succes:"criteres_succes",exemples:"exemples",options:"options",longueur:"longueur",creativite:"creativite",autonomie:"autonomie",profondeur_analyse:"profondeur_analyse",verbosity:"verbosity",reasoning:"reasoning",format_de_sortie:"format_de_sortie",prefill:"prefill"},en:{role:"role",nom:"name",competences:"skills",objectif:"objective",audience:"audience",type:"type",contexte:"context",instructions_sequentielles:"sequential_instructions",criteres_succes:"success_criteria",exemples:"examples",options:"options",longueur:"length",creativite:"creativity",autonomie:"autonomy",profondeur_analyse:"analysis_depth",verbosity:"verbosity",reasoning:"reasoning",format_de_sortie:"output_format",prefill:"prefill"},de:{role:"rolle",nom:"name",competences:"kompetenzen",objectif:"ziel",audience:"zielgruppe",type:"typ",contexte:"kontext",instructions_sequentielles:"sequentielle_anweisungen",criteres_succes:"erfolgskriterien",exemples:"beispiele",options:"optionen",longueur:"laenge",creativite:"kreativitaet",autonomie:"autonomie",profondeur_analyse:"analysetiefe",verbosity:"ausfuehrlichkeit",reasoning:"argumentation",format_de_sortie:"ausgabeformat",prefill:"vorausfuellung"}};return t[s.currentLanguage]||t.fr}function D(){console.log("🏗️ Construction du prompt XML avec les données:",n.data);const t=L();let e=`<prompt>
`;if(e+=`  <${t.role}>
`,n.data.roleCustom)e+=`    <${t.nom}>${n.data.roleCustom}</${t.nom}>
`;else if(n.data.role&&n.data.role!==""&&n.data.role!=="personnalisé"){const i={"consultant-senior":s.t("roles.senior_consultant"),"analyste-données":s.t("roles.data_analyst"),"expert-marketing":s.t("roles.marketing_expert"),"développeur-senior":s.t("roles.senior_developer"),"rédacteur-technique":s.t("roles.technical_writer")};e+=`    <${t.nom}>${i[n.data.role]||s.t("roles.expert","Expert dans le domaine")}</${t.nom}>
`}else e+=`    <${t.nom}>${s.t("roles.expert","Expert dans le domaine")}</${t.nom}>
`;if(n.data.competences){const i=n.data.competences.trim().replace(/,\s*$/,"");e+=`    <${t.competences}>${i}</${t.competences}>
`}e+=`  </${t.role}>

`,e+=`  <${t.objectif}>
`;const o=n.data.objective?n.data.objective.trim().replace(/,\s*$/,""):s.t("not_specified","Non spécifié");return e+=`    ${o}
`,e+=`  </${t.objectif}>

`,e+=`  <${t.audience}>
`,n.data.audience&&n.data.audience.length>0&&n.data.audience.forEach(i=>{e+=`    <${t.type}>${i}</${t.type}>
`}),e+=`  </${t.audience}>

`,n.data.context&&(e+=`  <${t.contexte}>
`,e+=`    ${n.data.context}
`,e+=`  </${t.contexte}>

`),n.data.instructions&&(e+=`  <${t.instructions_sequentielles}>
`,e+=`    ${n.data.instructions}
`,e+=`  </${t.instructions_sequentielles}>

`),n.data.criteres&&(e+=`  <${t.criteres_succes}>
`,e+=`    ${n.data.criteres}
`,e+=`  </${t.criteres_succes}>

`),n.data.exemples&&(e+=`  <${t.exemples}>
`,e+=`    ${n.data.exemples}
`,e+=`  </${t.exemples}>

`),e+=`  <${t.options}>
`,e+=`    <${t.longueur}>${u("longueur",n.data.longueur||"moyenne")}</${t.longueur}>
`,e+=`    <${t.creativite}>${u("creativite",n.data.creativite||"modérée")}</${t.creativite}>
`,e+=`    <${t.autonomie}>${u("autonomie",n.data.autonomie||"medium")}</${t.autonomie}>
`,e+=`    <${t.profondeur_analyse}>${u("profondeur",n.data.profondeur||"medium")}</${t.profondeur_analyse}>
`,e+=`    <${t.verbosity}>${u("verbosity",n.data.verbosity||"balanced")}</${t.verbosity}>
`,n.data.reasoning&&(e+=`    <${t.reasoning}>${u("reasoning",n.data.reasoning)}</${t.reasoning}>
`),e+=`  </${t.options}>

`,e+=`  <${t.format_de_sortie}>
`,e+=`    <${t.type}>${u("format",n.data.format||"rapport")}</${t.type}>
`,n.data.prefill&&(e+=`    <${t.prefill}>${n.data.prefill}</${t.prefill}>
`),e+=`  </${t.format_de_sortie}>
`,e+="</prompt>",e}function T(){console.log("🔗 Attachement des event listeners pour les suggestions"),document.querySelectorAll('.suggestion-tag[data-suggestion="objectif"]').forEach(t=>{t.addEventListener("click",function(){const e=document.getElementById("objective");if(e){const o=e.value,i=this.textContent;if(o.includes(i)){console.log("📝 Suggestion déjà présente:",i);return}o.trim()?e.value=o+(o.endsWith(",")||o.endsWith(", ")?" ":", ")+i:e.value=i,e.focus(),console.log("📝 Suggestion objectif appliquée:",i)}})}),document.querySelectorAll('.suggestion-tag[data-suggestion="competence"]').forEach(t=>{t.addEventListener("click",function(){const e=document.getElementById("competences");if(e){const o=e.value,i=this.textContent;if(o.includes(i)){console.log("🎯 Suggestion déjà présente:",i);return}o.trim()?e.value=o+(o.endsWith(",")||o.endsWith(", ")?" ":", ")+i:e.value=i,e.focus(),console.log("🎯 Suggestion compétence appliquée:",i)}})}),console.log("✅ Event listeners des suggestions attachés")}function R(){console.log("📚 Rendu de la bibliothèque");const t=document.querySelector("#library-view .content");if(!t){console.error("❌ Container de la bibliothèque non trouvé");return}let e="";[{id:"strategy",name_fr:"Stratégie",name_en:"Strategy",name_de:"Strategie"},{id:"content",name_fr:"Contenu",name_en:"Content",name_de:"Inhalt"},{id:"analysis",name_fr:"Analyse",name_en:"Analysis",name_de:"Analyse"}].forEach(i=>{const r=i[`name_${s.currentLanguage}`]||i.name_fr,c=B(i.id);c.length>0&&(e+=`
        <div class="category-section">
          <h3 style="margin: 24px 0 16px 0; color: var(--color-text-primary); font-size: 18px; font-weight: 600;">${r}</h3>
      `,c.forEach(a=>{const p=a[`title_${s.currentLanguage}`]||a.title_fr,d=a[`description_${s.currentLanguage}`]||a.description_fr;e+=`
          <div class="template-card" data-template-id="${a.id}" style="background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: 16px; margin-bottom: 12px; cursor: pointer; transition: all var(--transition-fast);">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
              <h4 style="margin: 0; color: var(--color-text-primary); font-size: 16px; font-weight: 500;">${p}</h4>
              <button class="copy-template-btn" data-template-id="${a.id}" style="background: var(--color-accent); color: var(--color-text-primary); border: none; padding: 4px 8px; border-radius: 4px; font-size: 12px; cursor: pointer;">
                ${s.t("copy_button")}
              </button>
            </div>
            <p style="margin: 0; color: var(--color-text-secondary); font-size: 14px; line-height: 1.4;">${d}</p>
          </div>
        `}),e+="</div>")}),t.innerHTML=e,z()}function z(){console.log("🔗 Attachement des event listeners pour les templates"),document.querySelectorAll(".copy-template-btn").forEach(t=>{t.addEventListener("click",function(e){e.stopPropagation();const o=this.getAttribute("data-template-id"),i=h(o);if(i){C(i.prompt),console.log("📋 Template copié:",o);const r=this.textContent;this.textContent="✅",this.style.background="var(--color-success)",setTimeout(()=>{this.textContent=r,this.style.background="var(--color-accent)"},1500)}})}),document.querySelectorAll(".template-card").forEach(t=>{t.addEventListener("click",function(){const e=this.getAttribute("data-template-id"),o=h(e);o&&O(o)})})}function C(t){try{navigator.clipboard.writeText(t).then(()=>{console.log("✅ Template copié avec succès")}).catch(e=>{console.error("❌ Erreur lors de la copie:",e),g(t)})}catch(e){console.error("❌ Clipboard API non supportée:",e),g(t)}}function O(t){C(t.prompt)}document.addEventListener("DOMContentLoaded",function(){console.log("🚀 DOM loaded, initializing GRID extension...");try{console.log("🔍 Vérifications de base:"),console.log("  - Vues trouvées:",document.querySelectorAll('[id$="-view"]').length),console.log("  - Boutons avec data-action:",document.querySelectorAll("[data-action]").length);const t=document.getElementById("language-selector");t&&(t.value=s.currentLanguage,t.addEventListener("change",function(r){console.log("🌍 Changement de langue:",r.target.value),s.setLanguage(r.target.value)}),console.log("  ✅ Sélecteur de langue configuré")),s.updateDOM(),T();const e=document.querySelector('[data-action="start-builder"]'),o=document.querySelector('[data-action="show-library"]');console.log("🔍 Boutons page d'accueil:"),console.log("  - start-builder trouvé:",!!e),console.log("  - show-library trouvé:",!!o),e&&(e.addEventListener("click",function(r){console.log("🎯 CLICK détecté sur start-builder"),_()}),console.log("  ✅ Event listener attaché: start-builder")),o&&(o.addEventListener("click",function(r){console.log("🎯 CLICK détecté sur show-library"),A()}),console.log("  ✅ Event listener attaché: show-library")),[{action:"go-home",func:v},{action:"go-step1",func:x},{action:"go-step2",func:E},{action:"go-step3",func:S},{action:"generate-prompt",func:I},{action:"copy-prompt",func:w}].forEach(({action:r,func:c})=>{const a=document.querySelectorAll(`[data-action="${r}"]`);console.log(`🔍 Boutons ${r} trouvés:`,a.length),a.forEach((p,d)=>{p.addEventListener("click",function(m){console.log(`🎯 CLICK détecté sur ${r} (bouton ${d+1})`),c()})}),a.length>0&&console.log(`  ✅ Event listeners attachés: ${r} (${a.length} boutons)`)}),console.log("✅ GRID extension initialized successfully")}catch(t){console.error("❌ Erreur lors de l'initialisation:",t)}});window.debugGrid={showView:l,goHome:v,startBuilder:_,goToStep1:x,goToStep2:E,goToStep3:S,showLibrary:A,generatePrompt:I,test:()=>{console.log("🧪 Test manuel lancé"),_()}};
